# Strong Password Generator

A simple web application using Flask to generate complex, secure passwords.

## Features
- Backend in Python using Flask
- Frontend with HTML, CSS, and JavaScript
- One-click password generation

## How to Run

1. Install Flask:

```
pip install flask
```

2. Run the application:

```
python app.py
```

3. Open your browser and go to:

```
http://127.0.0.1:5000
```
